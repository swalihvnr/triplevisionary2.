bl_info = {
    "name": "VSE Multi Audio Streams",
    "author": "Created by Swalih | Powered by Triple Visionary",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "Video Sequence Editor > N-Panel > Multi Audio",
    "description": "Detects every audio stream inside a movie strip's source file and adds each one as its own sound strip",
    "category": "Sequencer",
}

import json
import os
import shutil
import subprocess

import bpy


def probe_audio_streams(path):
    cmd = [
        "ffprobe", "-v", "error", "-select_streams", "a",
        "-show_entries", "stream=index,codec_name,channels:stream_tags=language,title",
        "-of", "json", path,
    ]
    out = subprocess.check_output(cmd, text=True)
    return json.loads(out).get("streams", [])


class SEQUENCER_OT_add_all_audio_streams(bpy.types.Operator):
    bl_idname = "sequencer.add_all_audio_streams"
    bl_label = "Add All Audio Streams"
    bl_description = "Extract every audio stream from the movie strip's file and add each as a sound strip"
    bl_options = {'REGISTER', 'UNDO'}

    mute_extra_tracks: bpy.props.BoolProperty(
        name="Mute Extra Tracks",
        description="Keep every track after the first one muted so they do not play over each other",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        se = getattr(context.scene, "sequence_editor", None)
        return bool(se) and any(s.type == 'MOVIE' for s in se.sequences_all)

    def execute(self, context):
        try:
            return self._run(context)
        except FileNotFoundError:
            self.report({'ERROR'}, "ffmpeg/ffprobe not found. Install ffmpeg first")
            return {'CANCELLED'}
        except subprocess.CalledProcessError as e:
            self.report({'ERROR'}, f"ffmpeg failed: {e}")
            return {'CANCELLED'}

    def _run(self, context):
        scene = context.scene
        se = scene.sequence_editor

        selected = [s for s in context.selected_sequences if s.type == 'MOVIE']
        movies = selected or [s for s in se.sequences_all if s.type == 'MOVIE']

        total_added = 0
        for movie in movies:
            src = os.path.realpath(bpy.path.abspath(movie.filepath))
            if not os.path.isfile(src):
                self.report({'WARNING'}, f"Missing file: {src}")
                continue

            streams = probe_audio_streams(src)
            base = os.path.splitext(os.path.basename(src))[0]
            out_dir = os.path.join(os.path.dirname(src), f"{base}_audio_tracks")
            os.makedirs(out_dir, exist_ok=True)

            stale = [
                s for s in se.sequences_all
                if s.type == 'SOUND'
                and os.path.dirname(os.path.realpath(bpy.path.abspath(s.sound.filepath))) == out_dir
            ]
            for s in stale:
                se.sequences.remove(s)

            top_channel = max(s.channel for s in se.sequences_all) if len(se.sequences_all) else movie.channel

            added_here = 0
            for i, stream in enumerate(streams):
                lang = stream.get("tags", {}).get("language", "") or f"track{i + 1}"
                title = stream.get("tags", {}).get("title", "")
                dest = os.path.join(out_dir, f"{base}.{lang}.mka")

                if not os.path.isfile(dest):
                    subprocess.check_call([
                        "ffmpeg", "-y", "-v", "error", "-i", src,
                        "-map", f"0:a:{i}", "-vn", "-c:a", "copy", dest,
                    ])

                label = f"{base[:40]} [{lang}]{(' ' + title) if title else ''}"[:63]
                strip = se.sequences.new_sound(
                    label, dest,
                    channel=top_channel + 1 + i,
                    frame_start=int(movie.frame_start),
                )
                strip.show_waveform = True
                if i > 0 and self.mute_extra_tracks:
                    strip.mute = True
                added_here += 1

            total_added += added_here
            self.report({'INFO'},
                        f"{movie.name}: {len(streams)} audio stream(s), {added_here} strip(s) added")

        if total_added == 0:
            self.report({'WARNING'}, "No new audio streams found")
            return {'CANCELLED'}
        return {'FINISHED'}


class SEQUENCER_PT_multi_audio(bpy.types.Panel):
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Multi Audio"
    bl_label = "Multi Audio Streams"

    def draw(self, context):
        col = self.layout.column(align=True)
        col.prop(context.scene, "multi_audio_mute_extra")
        props = col.operator(SEQUENCER_OT_add_all_audio_streams.bl_idname,
                             text="Add All Audio Streams", icon='SPEAKER')
        props.mute_extra_tracks = context.scene.multi_audio_mute_extra


classes = (
    SEQUENCER_OT_add_all_audio_streams,
    SEQUENCER_PT_multi_audio,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.multi_audio_mute_extra = bpy.props.BoolProperty(
        name="Mute Extra Tracks",
        description="Mute every track after the first one",
        default=True,
    )


def unregister():
    del bpy.types.Scene.multi_audio_mute_extra
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
